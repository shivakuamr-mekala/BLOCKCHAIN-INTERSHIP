# Welcome to the Ether Coin Flip Tutorial

Ether Coin Flip is a simple full-stack web3 dapp that is built with

- React for the front end
- A solidity smart contract deployed to Base Sepolia
- Ethers.js to interact with the smart contract
- Data from a subgraph on The Graph Network

Read the tutorial blog [here](https://thegraph.com/blog/full-stack-dapp-on-base-tutorial/)!
